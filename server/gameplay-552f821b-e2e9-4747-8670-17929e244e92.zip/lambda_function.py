

import json
import boto3

ENDPOINT = 'https://rs84vi8zt5.execute-api.us-east-1.amazonaws.com/production1'
client = boto3.client('apigatewaymanagementapi', endpoint_url=ENDPOINT)
names = {}

def send_to_one(connection_id, body):
    print(connection_id)
    try:
        client.post_to_connection(ConnectionId=connection_id, Data=json.dumps(body).encode())
    except Exception as e:
        print(e)

def send_to_all(ids, body, exclude_connection_id=None):
    filtered_ids = [cid for cid in ids if cid != exclude_connection_id]
    all_connections = [send_to_one(cid, body) for cid in filtered_ids]
    return all_connections
    
# def send_to_all(ids, body, exclude_connection_id=None):
#     for cid in ids:
#         if cid != exclude_connection_id:
#             send_to_one(cid, body)


def lambda_handler(event, context):
    if 'requestContext' in event:
        connection_id = event['requestContext']['connectionId']
        route_key = event['requestContext']['routeKey']
        body = {}

        try:
            if 'body' in event:
                body = json.loads(event['body'])
        except Exception as e:
            print(e)

        if route_key == '$connect':
            print('Handling $connect')
        elif route_key == '$disconnect':
            print('Handling $disconnect', connection_id, names)
            del names[connection_id]
            print(names);
            # send_to_all(list(names.keys()), {'systemMessage': f'{names[connection_id]} has left the chat'})
            send_to_all(list(names.keys()), {'members': list(names.values())})
        elif route_key == '$default':
            print('Handling $default')
        elif route_key == 'setName':
            names[connection_id] = body.get('name')
            print(names);
            send_to_all(list(names.keys()), {'members': list(names.values())})
            send_to_all(list(names.keys()), {'systemMessage': f'{names[connection_id]} has joined the chat'})
            print(connection_id)
            print('Handling setName')
        # elif route_key == 'sendPublic':
        #     print('Handling sendPublic')
        #     if connection_id in names:
        #         message = {'publicMessage': f'{names[connection_id]}: {body.get("message")}'}
        #         send_to_all(list(names.keys()), message)
        elif route_key == 'answer':
            print('Handling answer')
            print(connection_id)
            print(names)
            message = {'publicMessage': f'{names[connection_id]}: {body.get("message")}'}
            
            
            
            
            send_to_all(list(names.keys()), message, exclude_connection_id=connection_id)
        else:
            print('Invalid routeKey')

    # No need to return a response body, since this is a WebSocket connection
    response = {
        'statusCode': 200,
    }
    return response
