const AWS = require('aws-sdk');
const client = new AWS.ApiGatewayManagementApi({
  endpoint: 'https://rs84vi8zt5.execute-api.us-east-1.amazonaws.com/production1'
});
const admin = require("firebase-admin");
admin.initializeApp(); // Initialize Firebase Admin SDK

const db = require("./db");
const gamesCollection = db.collection("testgames");

const sendToOne = async (connectionId, body) => {
  console.log(connectionId);
  try {
    await client.postToConnection({
      ConnectionId: connectionId,
      Data: JSON.stringify(body)
    }).promise();
  } catch (e) {
    console.log(e);
  }
};

const sendToAll = async (ids, body, excludeConnectionId = null) => {
  const filteredIds = ids.filter(cid => cid !== excludeConnectionId);
  const allConnections = filteredIds.map(cid => sendToOne(cid, body));
  await Promise.all(allConnections);
};

exports.handler = async (event, context) => {
  if (event.requestContext) {
    const connectionId = event.requestContext.connectionId;
    const routeKey = event.requestContext.routeKey;
    let body = {};

    try {
      if (event.body) {
        body = JSON.parse(event.body);
      }
    } catch (e) {
      console.log(e);
    }

    if (routeKey === '$connect') {
      console.log('Handling $connect');
    } else if (routeKey === '$disconnect') {
      console.log('Handling $disconnect', connectionId);
      // delete names[connectionId];
      // await sendToAll(Object.keys(names), { members: Object.values(names) });
    } else if (routeKey === '$default') {
      console.log('Handling $default');
    } else if (routeKey === 'setName') {
     
      console.log('Handling setName');
    } else if (routeKey === 'answer') {
      console.log('Handling answer');
      console.log(connectionId);
      
      const names = {};
      const snapshot = await gamesCollection
      .where("gameId", "==", body.gameId)
      .get();
  
    const usersCollection = db.collection("userData");
    const promises = [];

    for (const doc of snapshot.docs) {
      doc.data().teamScores.forEach((team) => {
        const parts = team.teamId._path.segments;
        const teamName = parts[parts.length - 1];
        console.log(teamName);
    
        const userDataPromise = usersCollection
          .where("t_name", "==", teamName)
          .get()
          .then((userDataSnapshot) => {
            const userPromises = [];
            userDataSnapshot.forEach((user) => {
              const tempUser = user.data();
              
              if (tempUser.hasOwnProperty("connectionId") && tempUser.connectionId !== null) {
                names[tempUser.connectionId] = tempUser.firstName;
                userPromises.push(Promise.resolve());
              }
            });
            return Promise.all(userPromises);
          });
    
        promises.push(userDataPromise);
      });
    }

    // Wait for all asynchronous operations to complete
    await Promise.all(promises);
      
      console.log(names);
      const message = { publicMessage: `${names[connectionId]}: ${body.message}` };
      await sendToAll(Object.keys(names), message, connectionId);
    } else if (routeKey === 'sendPublic') {
      const names = {};
      const snapshot = await gamesCollection
      .where("gameId", "==", body.gameId)
      .get();
  
    const usersCollection = db.collection("userData");
    const promises = [];

    for (const doc of snapshot.docs) {
      doc.data().teamScores.forEach((team) => {
        const parts = team.teamId._path.segments;
        const teamName = parts[parts.length - 1];
        console.log(teamName);
    
        const userDataPromise = usersCollection
          .where("t_name", "==", teamName)
          .get()
          .then((userDataSnapshot) => {
            const userPromises = [];
            userDataSnapshot.forEach((user) => {
              const tempUser = user.data();
              
              if (tempUser.hasOwnProperty("connectionId") && tempUser.connectionId !== null) {
                names[tempUser.connectionId] = tempUser.firstName;
                userPromises.push(Promise.resolve());
              }
            });
            return Promise.all(userPromises);
          });
    
        promises.push(userDataPromise);
      });
    }

    // Wait for all asynchronous operations to complete
    await Promise.all(promises);
      
      console.log(names);
      const message = { origin:"chat", publicMessage: `${names[connectionId]}: ${body.message}` };
      await sendToAll(Object.keys(names), message);
    }else {
      console.log('Invalid routeKey');
    }
  }

  // No need to return a response body, since this is a WebSocket connection
  const response = {
    statusCode: 200
  };
  return response;
};
