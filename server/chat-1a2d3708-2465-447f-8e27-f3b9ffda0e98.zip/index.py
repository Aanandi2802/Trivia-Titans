

import json
import boto3

ENDPOINT = 'https://tbktzinsad.execute-api.us-east-1.amazonaws.com/production'
client = boto3.client('apigatewaymanagementapi', endpoint_url=ENDPOINT)
names = {}

def send_to_one(connection_id, body):
    try:
        client.post_to_connection(ConnectionId=connection_id, Data=json.dumps(body).encode())
    except Exception as e:
        print(e)

def send_to_all(ids, body):
    all_connections = [send_to_one(cid, body) for cid in ids]
    return all_connections

def lambda_handler(event, context):
    if 'requestContext' in event:
        connection_id = event['requestContext']['connectionId']
        route_key = event['requestContext']['routeKey']
        body = {}

        try:
            if 'body' in event:
                body = json.loads(event['body'])
        except Exception as e:
            print(e)

        if route_key == '$connect':
            print('Handling $connect')
        elif route_key == '$disconnect':
            print('Handling $disconnect')
            send_to_all(list(names.keys()), {'systemMessage': f'{names[connection_id]} has left the chat'})
            del names[connection_id]
            send_to_all(list(names.keys()), {'members': list(names.values())})
        elif route_key == '$default':
            print('Handling $default')
        elif route_key == 'setName':
            names[connection_id] = body.get('name')
            send_to_all(list(names.keys()), {'members': list(names.values())})
            print(names)
            send_to_all(list(names.keys()), {'systemMessage': f'{names[connection_id]} has joined the chat'})
            print(connection_id)
            print('Handling setName')
        elif route_key == 'sendPublic':
            print('Handling sendPublic')
            if connection_id in names:
                message = {'publicMessage': f'{names[connection_id]}: {body.get("message")}'}
                send_to_all(list(names.keys()), message)
        elif route_key == 'sendPrivate':
            # to = next((key for key, value in names.items() if value == body.get('to')), None)
            # if to:
            #     send_to_one(to, {'privateMessage': f'{names[connection_id]}: {body.get("message")}'})
            
            print('Handling answer')
            print(connection_id)
            print(names)
            # player_name = names[connection_id]
            # player_answer = body['answer']
                # Process the player's answer here (e.g., check if it's correct)
                # For this example, we'll simply broadcast the answer to all players.
            message = {'publicMessage': f'{names[connection_id]}: {body.get("message")}'}
            send_to_all(list(names.keys()), message)
            
                
        elif route_key == 'answer':  # New route key for handling trivia answers
            print('Handling answer')
            if connection_id in names:
                # player_answer = body.get('answer')
                # if player_answer:
                #     # Process the player's answer here (e.g., check if it's correct)
                #     # For this example, we'll simply broadcast the answer to all players.
                message = {'triviaAnswer': f'{names[connection_id]}: {body.get("message")}'}
                send_to_all(list(names.keys()), message)        
        else:
            print('Invalid routeKey')

    # No need to return a response body, since this is a WebSocket connection
    response = {
        'statusCode': 200,
    }
    return response
