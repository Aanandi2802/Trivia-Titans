const AWS = require("aws-sdk");
const admin = require("firebase-admin");
admin.initializeApp(); // Initialize Firebase Admin SDK

const db = require("./db")
const gamesCollection = db.collection("testgames");

const sendToOne = async (id, body) => {
  try {
    const ENDPOINT = "https://rs84vi8zt5.execute-api.us-east-1.amazonaws.com/production1";
    const client = new AWS.ApiGatewayManagementApi({ endpoint: ENDPOINT });
    await client
      .postToConnection({
        ConnectionId: id,
        Data: Buffer.from(JSON.stringify(body)),
      })
      .promise();
  } catch (err) {
    console.error(err);
  }
};

exports.handler = async (event, context) => {
  const { connectionId } = event.requestContext;
  const {userId} = JSON.parse(event.body);
  
  const collection = db.collection("userData");
  const user = collection.doc(userId);
  await user.update({
    connectionId
  })
  await sendToOne(connectionId,{connectionId})
  
  // TODO implement
  const response = {
    statusCode: 200,
    body: JSON.stringify('ConnectionId set up successfully'),
  };
  return response;
};
