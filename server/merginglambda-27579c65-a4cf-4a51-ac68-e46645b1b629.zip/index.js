const AWS = require("aws-sdk");
const admin = require("firebase-admin");
admin.initializeApp(); // Initialize Firebase Admin SDK

const db = require("./db");
const gamesCollection = db.collection("testgames");

const sendToOne = async (id, body) => {
  try {
    const ENDPOINT = "https://rs84vi8zt5.execute-api.us-east-1.amazonaws.com/production1";
    const client = new AWS.ApiGatewayManagementApi({ endpoint: ENDPOINT });
    await client
      .postToConnection({ 
        ConnectionId: id,
        Data: Buffer.from(JSON.stringify(body)),
      })
      .promise();
  } catch (err) {
    console.error(err);
  }
};

exports.handler = async (event) => {
  const currentTime = new Date();
  const startTime = admin.firestore.Timestamp.fromDate(currentTime);
  const endTime = admin.firestore.Timestamp.fromDate(new Date(currentTime.getTime() + 30 * 60000)); // 30 minutes later
  const snapshot = await gamesCollection
      .where("startTime", ">=", startTime)
      .where("startTime", "<", endTime)
      .get();
  
  try {
    const usersCollection = db.collection("userData");
    const promises = [];

for (const doc of snapshot.docs) {
  doc.data().teamScores.forEach((team) => {
    const parts = team.teamId._path.segments;
    const teamName = parts[parts.length - 1];
    console.log(teamName);

    const userDataPromise = usersCollection
      .where("t_name", "==", teamName)
      .get()
      .then((userDataSnapshot) => {
        const userPromises = [];
        userDataSnapshot.forEach((user) => {
          const tempUser = user.data();
          console.log(tempUser);
          if (tempUser.hasOwnProperty("connectionId") && tempUser.connectionId !== null) {
            userPromises.push(
              sendToOne(tempUser.connectionId, {
                gameDetails: doc.data(),
                origin: "startGame",
                message: "Game has started!",
              })
            );
          }
        });
        return Promise.all(userPromises);
      });

    promises.push(userDataPromise);
  });
}

// Wait for all asynchronous operations to complete
await Promise.all(promises);

return {
  statusCode: 200,
  body: JSON.stringify({ message: "Games started successfully" }),
};
  } catch (ex) {
    console.log(ex);
    return {
      statusCode: 500,
      body: JSON.stringify({ message: "Error starting game" }),
    };
  }
};